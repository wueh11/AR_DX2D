#pragma once
class Fireplace
{
};

