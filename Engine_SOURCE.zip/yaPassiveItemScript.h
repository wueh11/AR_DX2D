#pragma once
class PassiveItemScript
{
};

