#pragma once
class Spike
{
};

