#include "yaPlayerScript.h"
#include "yaPlayer.h"

#include "yaObject.h"
#include "yaGameObject.h"

#include "yaResources.h"
#include "yaInput.h"
#include "yaTime.h"

#include "yaTransform.h"
#include "yaAnimator.h"
#include "yaRigidbody.h"

#include "yaSpriteRenderer.h"
#include "yaImageRenderer.h"

#include "yaItemManager.h"
#include "yaTear.h"
#include "yaItem.h"
#include "yaActiveItem.h"
#include "yaPickup.h"
#include "yaDropBomb.h"
#include "yaPill.h"
#include "yaCard.h"
#include "yaTrinket.h"

namespace ya
{
	PlayerScript::PlayerScript()
		: Script()
		, mTransform(nullptr)
		, mRigidbody(nullptr)
		, mHead(nullptr)
		, mBody(nullptr)
		, mStarflash(nullptr)
		, mGainItem(nullptr)

		, mInvincibleTime(0.0f)
		, mInvincibleTimeMax(1.5f)
		, mbInvincible(false)
		, mItemActionTime(0.0f)
		, mItemActionTimeMax(1.0f)
		, mbItemAction(false)
		, mDropTime(0.0f)
		, mDropTimeMax(2.0f)
		, mGainItemTime(0.0f)
		, mGainItemTimeMax(1.0f)
		, mbGainItem(true)
	{
	}
	PlayerScript::~PlayerScript()
	{
	}
	void PlayerScript::Initialize()
	{
		mTransform = GetOwner()->GetComponent<Transform>();
		mRigidbody = GetOwner()->AddComponent<Rigidbody>();

		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Status status = player->GetStatus();

		mRigidbody->SetLimitVelocity(Vector3(1.0f + status.speed, 1.0f + status.speed, 0.0f));

		SpriteRenderer* rd = GetOwner()->AddComponent<SpriteRenderer>();
		std::shared_ptr<Mesh> mesh = Resources::Find<Mesh>(L"RectMesh");
		rd->SetMesh(mesh);
		std::shared_ptr<Material> material = Resources::Find<Material>(L"isaacMaterial");
		rd->SetMaterial(material);
		std::shared_ptr<Texture> texture = material->GetTexture();

		Animator* animator = GetOwner()->AddComponent<Animator>();
		animator->Create(L"None", texture, Vector2(0.0f, 480.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
		animator->Create(L"Hurt", texture, Vector2(128.0f, 192.0f), Vector2(64.0f, 64.0f), Vector2(0.0f, -0.025f), 1, 0.1f);
		animator->Create(L"Die", texture, Vector2(0.0f, 128.0f), Vector2(64.0f, 64.0f), Vector2(0.0f, -0.025f), 1, 0.2f);
		animator->Add(L"Die", texture, Vector2(128.0f, 192.0f), Vector2(64.0f, 64.0f), Vector2(0.0f, -0.025f), 1, 0.2f);
		animator->Add(L"Die", texture, Vector2(192.0f, 128.0f), Vector2(64.0f, 64.0f), Vector2(0.0f, -0.025f), 1, 0.3f);
		animator->Play(L"None", true);

		//animator->GetCompleteEvent(L"hurt") = std::bind(&PlayerScript::Idle, this);

		{ // body
			mBody = object::Instantiate<GameObject>(eLayerType::Player, mTransform);

			SpriteRenderer* mMr = mBody->AddComponent<SpriteRenderer>();
			mMr->SetMesh(mesh);
			mMr->SetMaterial(material);

			Animator* bodyAnimator = mBody->AddComponent<Animator>();
			bodyAnimator->Create(L"None", texture, Vector2(0.0f, 480.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			bodyAnimator->Create(L"FrontIdle", texture, Vector2(0.0f, 32.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			bodyAnimator->Create(L"FrontWalk", texture, Vector2(192.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 2, 0.1f);
			bodyAnimator->Add(L"FrontWalk", texture, Vector2(0.0f, 32.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 8, 0.1f);
			bodyAnimator->Create(L"SideIdle", texture, Vector2(0.0f, 64.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			bodyAnimator->Create(L"SideWalk", texture, Vector2(0.0f, 64.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 8, 0.1f);
			bodyAnimator->Create(L"ItemIdle", texture, Vector2(448.0f, 32.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			bodyAnimator->Create(L"ItemWalk", texture, Vector2(448.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 2, 0.1f);
			bodyAnimator->Add(L"ItemWalk", texture, Vector2(256.0f, 32.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 18, 0.1f, 8, 3);
			bodyAnimator->Play(L"FrontIdle", true);
		}

		{ // head
			mHead = object::Instantiate<GameObject>(eLayerType::Player, mTransform);

			SpriteRenderer* mMr = mHead->AddComponent<SpriteRenderer>();
			mMr->SetMesh(mesh);
			mMr->SetMaterial(material);

			Animator* headAnimator = mHead->AddComponent<Animator>();
			headAnimator->Create(L"None", texture, Vector2(0.0f, 480.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"FrontIdle", texture, Vector2(0.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"FrontAttack", texture, Vector2(32.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"SideIdle", texture, Vector2(64.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"SideAttack", texture, Vector2(96.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"BackIdle", texture, Vector2(128.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"BackAttack", texture, Vector2(160.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			headAnimator->Create(L"ItemIdle", texture, Vector2(256.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 1, 0.1f);
			
			headAnimator->Play(L"FrontIdle", true);
		}

		Transform* headTr = mHead->GetComponent<Transform>();
		headTr->SetPosition(Vector3(0.0f, 0.15f, 0.0f));
		Transform* bodyTr = mBody->GetComponent<Transform>();
		bodyTr->SetPosition(Vector3(0.0f, -0.15f, 0.0f));

		{ // starflash
			mStarflash = object::Instantiate<GameObject>(eLayerType::Player, mTransform);

			std::shared_ptr<Material> starflashMaterial = Resources::Find<Material>(L"starflashMaterial");
			std::shared_ptr<Texture> starflashTexture = starflashMaterial->GetTexture();
			
			SpriteRenderer* starflashMr = mStarflash->AddComponent<SpriteRenderer>();
			starflashMr->SetMesh(mesh);
			starflashMr->SetMaterial(starflashMaterial);

			Animator* starflashAnimator = mStarflash->AddComponent<Animator>();
			starflashAnimator->Create(L"starflash", starflashTexture, Vector2(0.0f, 0.0f), Vector2(32.0f, 32.0f), Vector2::Zero, 12, 0.1f, 4, 3);
			starflashAnimator->Play(L"starflash", true);

			Transform* starflashTr = mStarflash->GetComponent<Transform>();
			starflashTr->SetPosition(Vector3(0.0f, 0.7f, 1.0f));
			//starflashTr->SetScale(Vector3(0.64f, 0.64f, 1.0f));
			mStarflash->Pause();
		}

		{
			mGainItem = object::Instantiate<GameObject>(eLayerType::Player, mTransform);

			std::shared_ptr<Material> gainItemMaterial = Resources::Find<Material>(L"gainItemMaterial");
			ImageRenderer* gainItemMr = mGainItem->AddComponent<ImageRenderer>();
			gainItemMr->SetMesh(mesh);
			gainItemMr->SetMaterial(gainItemMaterial);

			Transform* gainItemTr = mGainItem->GetComponent<Transform>();
			gainItemTr->SetPosition(Vector3(0.0f, 0.7f, 1.0f));
			mGainItem->Pause();
		}
	}

	void PlayerScript::Update()
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		
		Player::Info info = player->GetInfo();
		if (info.heart < 0)
			player->SetHeart(0);

		Player::Items items = player->GetItem();

		Vector3 pos = mTransform->GetPosition();

		if (mbInvincible)
		{
			if (mInvincibleTime > 0.0f)
			{
				mInvincibleTime -= Time::DeltaTime();
			}
			else
			{
				mbInvincible = false;
				Idle();
			}
		}

		if (mbItemAction)
		{
			if (mItemActionTime > 0.0f)
			{
				mItemActionTime -= Time::DeltaTime();
			}
			else
			{
				mbItemAction = false;
				mStarflash->Pause();
				mGainItem->Pause();
				Idle();
			}
		}

		if (!mbGainItem)
		{
			if (mGainItemTime > 0.0f)
				mGainItemTime -= Time::DeltaTime();
			else
				mbGainItem = true;
		}

		Move();
		Attack();

		// ��ź
		if (Input::GetKeyDown(eKeyCode::E))
		{
			if (player->GetPickup().bomb > 0)
			{
				DropBomb* bomb = new DropBomb(pos);
				Scene* scene = SceneManager::GetActiveScene();
				Layer& layer = scene->GetLayer(eLayerType::Item);
				layer.AddGameObject(bomb);

				player->AddBomb(-1);
			}
		}

		// ��Ƽ�� ������ ���
		if (Input::GetKeyDown(eKeyCode::SPACE))
		{
			if(items.activeItem != eActiveItem::None)
			{
				ItemObject* itemObject = ItemManager::GetItemObjects(eItemType::ActiveItem)[(UINT)items.activeItem];
				if (itemObject->GetCharge() == itemObject->GetGauge())
				{
					itemObject->PlayEvent();
					itemObject->resetCharge();
				}
			}
		}

		// �Ⱦ� ������ ��� 
		if (Input::GetKeyDown(eKeyCode::Q))
		{
			UseConsumable();
		}

		// ��ű�, �Ҹ�ǰ ���
		if (Input::GetKey(eKeyCode::LCTRL))
		{
			//3�ʰ� ������ ������ drop
			if (mDropTime > 0.0f)
			{
				mDropTime -= Time::DeltaTime();
			}
			else
			{
				mGainItemTime = mGainItemTimeMax;
				mbGainItem = false;
				ThrowConsumable();
				ThrowTrinket();
			}
		}
		else if (Input::GetKeyDown(eKeyCode::LCTRL))
		{
			mDropTime = mDropTimeMax;
		}
		else if (Input::GetKeyUp(eKeyCode::LCTRL))
		{
			mDropTime = mDropTimeMax;
		}



		if (Input::GetKeyDown(eKeyCode::N_9))
		{
			Hurt();
		}
		if (Input::GetKeyDown(eKeyCode::N_0))
		{
			Die();
		}
		if (Input::GetKeyDown(eKeyCode::N_1))
		{
			player->AddHeart(1);
		}
		if (Input::GetKeyDown(eKeyCode::N_2))
		{
			player->AddSoulHeart(1);
		}
		if (Input::GetKeyDown(eKeyCode::N_3))
		{
			player->AddMaxHeart(2);
		}
		if (Input::GetKeyDown(eKeyCode::N_4))
		{
			player->AddMaxHeart(-2);
		}

		if (Input::GetKeyDown(eKeyCode::N_8))
		{
			if (items.activeItem != eActiveItem::None)
			{
				ItemObject* itemObject = ItemManager::GetItemObjects(eItemType::ActiveItem)[(UINT)items.activeItem];
				itemObject->AddCharge(1);
			}
		}

	}

	void PlayerScript::FixedUpdate()
	{
	}
	void PlayerScript::Render()
	{
	}

	void PlayerScript::OnCollisionEnter(Collider2D* collider)
	{
		//GameObject* other = collider->GetOwner();
	}
	void PlayerScript::OnCollisionStay(Collider2D* collider)
	{
	}
	void PlayerScript::OnCollisionExit(Collider2D* collider)
	{
	}
	void PlayerScript::OnTriggerEnter(Collider2D* collider)
	{
	}
	void PlayerScript::OnTriggerStay(Collider2D* collider)
	{
	}
	void PlayerScript::OnTriggerExit(Collider2D* collider)
	{
	}

	void PlayerScript::Idle()
	{
		Animator* animator = GetOwner()->GetComponent<Animator>();
		Animator* headAnimator = mHead->GetComponent<Animator>();
		Animator* bodyAnimator = mBody->GetComponent<Animator>();

		animator->Play(L"None", false);
		headAnimator->Play(L"FrontIdle", false);
		bodyAnimator->Play(L"FrontIdle", false);
		mTransform->SetScale(Vector3(0.66f, 0.66f, 1.0f));
	}

	void PlayerScript::Move()
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Status status = player->GetStatus();
		float speed = 2.0f + status.speed;
		Rigidbody* rigidbody = player->GetComponent<Rigidbody>();
		rigidbody->SetLimitVelocity(Vector3(speed, speed, 0.0f));

		float s = 20.0f;

		/// �̵�
		if (Input::GetKey(eKeyCode::W))
			mRigidbody->AddForce(Vector3(0.0f, s, 0.0f));
		else if (Input::GetKey(eKeyCode::S))
			mRigidbody->AddForce(Vector3(0.0f, -s, 0.0f));
		
		if (Input::GetKey(eKeyCode::A))
			mRigidbody->AddForce(Vector3(-s, 0.0f, 0.0f));
		else if (Input::GetKey(eKeyCode::D))
			mRigidbody->AddForce(Vector3(s, 0.0f, 0.0f));


		Animator* headAnimator = mHead->GetComponent<Animator>();
		Animator* bodyAnimator = mBody->GetComponent<Animator>();

		if (!mbInvincible)
		{
			// �ִϸ��̼�
			if (!mbItemAction)
			{
				if (Input::GetKeyDown(eKeyCode::W))
				{
					headAnimator->Play(L"BackIdle", true);
					bodyAnimator->Play(L"FrontWalk", true);
				}
				else if (Input::GetKeyDown(eKeyCode::S))
				{
					headAnimator->Play(L"FrontIdle", true);
					bodyAnimator->Play(L"FrontWalk", true);
				}
				else if (Input::GetKeyDown(eKeyCode::A))
				{
					headAnimator->Play(L"SideIdle", true);
					bodyAnimator->Play(L"SideWalk", true);
				}
				else if (Input::GetKeyDown(eKeyCode::D))
				{
					headAnimator->Play(L"SideIdle", true);
					bodyAnimator->Play(L"SideWalk", true);
				}

				if (Input::GetKeyNone(eKeyCode::W) && Input::GetKeyNone(eKeyCode::A) && Input::GetKeyNone(eKeyCode::S) && Input::GetKeyNone(eKeyCode::D))
				{
					bodyAnimator->Play(L"FrontIdle", true);
				}

				Transform* headTr = mHead->GetComponent<Transform>();
				Transform* bodyTr = mBody->GetComponent<Transform>();

				if (Input::GetKeyDown(eKeyCode::LEFT) || Input::GetKeyDown(eKeyCode::A))
				{
					headTr->SetRotation(Vector3(0.0f, XM_PI, 0.0f));
					bodyTr->SetRotation(Vector3(0.0f, XM_PI, 0.0f));
				}
				else if (Input::GetKeyDown(eKeyCode::RIGHT) || Input::GetKeyDown(eKeyCode::D))
				{
					headTr->SetRotation(Vector3(0.0f, 0.0f, 0.0f));
					bodyTr->SetRotation(Vector3(0.0f, 0.0f, 0.0f));
				}
			}
			else
			{
				if (Input::GetKeyDown(eKeyCode::W) || Input::GetKeyDown(eKeyCode::S) || Input::GetKeyDown(eKeyCode::A) || Input::GetKeyDown(eKeyCode::D))
					bodyAnimator->Play(L"ItemWalk", true);
	
				if (Input::GetKeyUp(eKeyCode::W) || Input::GetKeyUp(eKeyCode::S) || Input::GetKeyUp(eKeyCode::A) || Input::GetKeyUp(eKeyCode::D))
					bodyAnimator->Play(L"ItemIdle", true);
			}
		}

		/*Vector3 pos = mTransform->GetPosition();
		mTransform->SetPosition(Vector3(pos.x, pos.y, pos.y));*/
	}

	void PlayerScript::Attack()
	{
		Animator* animator = GetOwner()->GetComponent<Animator>();
		Animator* headAnimator = mHead->GetComponent<Animator>();
		Animator* bodyAnimator = mBody->GetComponent<Animator>();

		// ���� �߻�
		if (Input::GetKeyDown(eKeyCode::UP))
		{
			headAnimator->Play(L"BackAttack", true);
			Tears(Vector3(0.0f, 1.0f, 0.0f));
		}
		else if (Input::GetKeyDown(eKeyCode::DOWN))
		{
			headAnimator->Play(L"FrontAttack", true);
			Tears(Vector3(0.0f, -1.0f, 0.0f));
		}
		else if (Input::GetKeyDown(eKeyCode::LEFT))
		{
			headAnimator->Play(L"SideAttack", true);
			Tears(Vector3(-1.0f, 0.0f, 0.0f));
		}
		else if (Input::GetKeyDown(eKeyCode::RIGHT))
		{
			headAnimator->Play(L"SideAttack", true);
			Tears(Vector3(1.0f, 0.0f, 0.0f));
		}

		if (Input::GetKeyUp(eKeyCode::UP))
		{
			headAnimator->Play(L"BackIdle", true);
		}
		else if (Input::GetKeyUp(eKeyCode::DOWN))
		{
			headAnimator->Play(L"FrontIdle", true);
		}
		else if (Input::GetKeyUp(eKeyCode::LEFT))
		{
			headAnimator->Play(L"SideIdle", true);
		}
		else if (Input::GetKeyUp(eKeyCode::RIGHT))
		{
			headAnimator->Play(L"SideIdle", true);
		}
	}

	void PlayerScript::ItemAction()
	{
		mItemActionTime = mItemActionTimeMax;
		mbItemAction = true;

		Animator* headAnimator = mHead->GetComponent<Animator>();
		Animator* bodyAnimator = mBody->GetComponent<Animator>();

		headAnimator->Play(L"ItemIdle", false);
		bodyAnimator->Play(L"ItemIdle", false);

		mTransform->SetScale(Vector3(0.66f, 0.66f, 1.0f));

		mStarflash->SetActive();
		mGainItem->SetActive();

		mGainItemTime = mGainItemTimeMax;
		mbGainItem = false;
	}

	void PlayerScript::Tears(Vector3 direction)
	{
		Tear* tear = new Tear(GetOwner(), direction);
		Scene* scene = SceneManager::GetActiveScene();
		Layer& layer = scene->GetLayer(eLayerType::Projectile);
		layer.AddGameObject(tear);
	}

	void PlayerScript::Hurt()
	{
		if (mbInvincible)
			return;

		Animator* animator = GetOwner()->GetComponent<Animator>();
		Animator* headAnimator = mHead->GetComponent<Animator>();
		Animator* bodyAnimator = mBody->GetComponent<Animator>();

		headAnimator->Play(L"None", false);
		bodyAnimator->Play(L"None", false);
		animator->Play(L"Hurt", false);

		mTransform->SetScale(Vector3(1.32f, 1.32f, 1.0f));

		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Info info = player->GetInfo();
		if (info.soulHeart > 0)
			player->AddSoulHeart(-1);
		else 
			player->AddHeart(-1);

		Invincible();
	}

	void PlayerScript::Die()
	{
		Animator* animator = GetOwner()->GetComponent<Animator>();
		Animator* headAnimator = mHead->GetComponent<Animator>();
		Animator* bodyAnimator = mBody->GetComponent<Animator>();

		headAnimator->Play(L"None", false);
		bodyAnimator->Play(L"None", false);
		animator->Play(L"Die", false);

		mTransform->SetScale(Vector3(1.32f, 1.32f, 1.0f));
	}

	/// <summary>
	/// ���� �ð�
	/// </summary>
	void PlayerScript::Invincible()
	{
		mInvincibleTime = mInvincibleTimeMax;
		mbInvincible = true;
	}

	void PlayerScript::gainActiveItem(ActiveItem* item)
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		
		eActiveItem active = item->GetActveItemType();
		player->SetActiveItem(active);
		ItemAction();

		SetGainItem(item->GetComponent<Animator>());
	}

	void PlayerScript::gainConsumable(Pickup* pickup)
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Items item = player->GetItem();

		eItemType type = pickup->GetItemType();

		if (type == eItemType::Pill)
		{
			Pill* pill = dynamic_cast<Pill*>(pickup);
			ePills type = pill->GetPillType();

			if (item.pill != ePills::None)
			{
				ThrowConsumable();
			}
			else if (item.card != eCards::None)
			{
				ThrowConsumable();
			}

			player->SetPill(type);

		}
		else if (type == eItemType::Card)
		{
			Card* card = dynamic_cast<Card*>(pickup);
			eCards type = card->GetCardType();

			if (item.card != eCards::None)
			{
				ThrowConsumable();
			}
			else if (item.pill != ePills::None)
			{
				ThrowConsumable();
			}

			player->SetCard(type);
		}

		ItemAction();
		SetGainItem(pickup->GetComponent<Animator>());
	}

	void PlayerScript::gainTrinket(Trinket* item)
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		ThrowTrinket();

		eTrinkets trinket = item->GetTrinketType();
		player->SetTrinket(trinket);
		ItemAction();
		SetGainItem(item->GetComponent<Animator>());
	}
	
	void PlayerScript::UseActiveItem()
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Items item = player->GetItem();
		ItemManager::GetItemObjects(eItemType::ActiveItem)[(UINT)item.activeItem]->PlayEvent();
	}

	void PlayerScript::UseConsumable()
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Items item = player->GetItem();
		
		if (item.pill != ePills::None)
		{
			ItemManager::GetItemObjects(eItemType::Pill)[(UINT)item.pill]->PlayEvent();
			player->SetPill(ePills::None);

			Pill* gainPill = ItemManager::CreatePill(item.pill);
			SetGainItem(gainPill->GetComponent<Animator>());
			gainPill->Death();
		}
		else if (item.card != eCards::None)
		{
			ItemManager::GetItemObjects(eItemType::Card)[(UINT)item.card]->PlayEvent();
			player->SetCard(eCards::None);

			Card* gainCard = ItemManager::CreateCard(item.card);
			SetGainItem(gainCard->GetComponent<Animator>());
			gainCard->Death();
		}

		ItemAction();
	}

	void PlayerScript::ThrowConsumable()
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Items item = player->GetItem();

		if (item.pill != ePills::None)
		{
			player->SetPill(ePills::None);
			Pill* pill = ItemManager::CreatePill(item.pill);
			pill->GetComponent<Transform>()->SetPosition(player->GetComponent<Transform>()->GetPosition());
		}

		if (item.card != eCards::None)
		{
			player->SetCard(eCards::None);
			Card* card = ItemManager::CreateCard(item.card);
			card->GetComponent<Transform>()->SetPosition(player->GetComponent<Transform>()->GetPosition());
		}
	}
	void PlayerScript::ThrowTrinket()
	{
		Player* player = dynamic_cast<Player*>(GetOwner());
		Player::Items item = player->GetItem();

		if (item.trinket != eTrinkets::None)
		{
			player->SetTrinket(eTrinkets::None);
			Trinket* trinket = ItemManager::CreateTrinket(item.trinket);
			trinket->GetComponent<Transform>()->SetPosition(player->GetComponent<Transform>()->GetPosition());
		}
	}

	void PlayerScript::SetGainItem(Animator* animator)
	{
		ImageRenderer* gainItemRenderer = mGainItem->GetComponent<ImageRenderer>();
		if (animator != nullptr)
		{
			std::shared_ptr<Texture> texture = animator->GetActiveAnimation()->GetAtlas();
			Animation::Sprite sprite = animator->GetActiveAnimation()->GetSprite();
			gainItemRenderer->SetSprite(texture, sprite.leftTop, sprite.size, sprite.atlasSize);
		}
	}
}