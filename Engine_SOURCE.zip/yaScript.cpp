#include "yaScript.h"

namespace ya
{
	Script::Script()
		: Component(eComponentType::Script)
	{
	}

	Script::~Script()
	{
	}

	void Script::Initialize()
	{
	}

	void Script::Update()
	{
	}

	void Script::FixedUpdate()
	{
	}
	void Script::Render()
	{
	}
}