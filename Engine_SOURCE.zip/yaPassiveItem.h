#pragma once
class PassiveItem
{
};

