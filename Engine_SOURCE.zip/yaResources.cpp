#include "yaResources.h"

namespace ya
{
	std::map<std::wstring, std::shared_ptr<Resource>> Resources::mResources;
}
