#include "yaResource.h"

namespace ya
{
	Resource::Resource(eResourceType type)
		: mType(type)
	{
	}
	Resource::~Resource()
	{
	}
}