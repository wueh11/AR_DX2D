#pragma once

namespace ya
{
	class Prefab
	{
	};
}

